<form action="datos.php" method="post">
    <label for="">nombre</label><br>
    <input type="text" name="bandera" id="" value ="1" hidden>
    <input type="text" name="id" id=""><br>
    <input type="text" name="nombre" id=""><br>
    <label for="">telefono</label><br>
    <input type="text" name="telefono" id=""><br>
    <label for="">genero</label><br>
    <input type="text" name="genero" id=""><br><br>
    <input type="submit" value="enviar">
</form>